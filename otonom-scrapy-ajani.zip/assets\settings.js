import{r as m,j as e,c as A,R as T}from"./client-BK6F4jnW.js";const b=`Sen kıdemli bir Python ve Scrapy geliştiricisisi ve Reverse Engineering uzmanısın.
Kullanıcı senin için hedef sitelerde adım adım dolaştı ve verileri topladı.

JSON formatında yapılandırılmış veri alacaksın. Her adımda:
1. HTML öğeleri ve onun bulunduğu sayfa
2. API istekleri ve yanıtları

KURALLAR:
1. API (XHR/Fetch) verisi varsa DAİMA onu kullanmayı (JSON Parse) önceliklendir.
2. Sınıf ismi \`{SPIDER_NAME}Spider\` olsun.
3. Çıktıyı \`yield\` kullanarak verilen format'taki dictionary döndür.
4. Çekilen verilerdeki boşlukları \`.strip()\` ile temizle.
5. Hata almamak için try-except kullan.
6. SADECE ÇALIŞTIRILABİLİR PYTHON KODUNU VER. Markdown backticks dışında açıklama yazma.`,o={apiKey:"",apiModel:"gemini-2.5-flash",apiTimeout:30,maxElements:500,delayMs:1e3,autoScroll:!0,theme:"dark",notifications:!0,logLevel:"info",enableDebug:!1,cacheData:!0,retryAttempts:3,systemPrompt:b},z=()=>{const[i,x]=m.useState(o),[g,p]=m.useState({text:"",type:""}),[u,d]=m.useState({text:"",type:""}),[y,f]=m.useState(!1);m.useEffect(()=>{const t=document.createElement("link");t.rel="stylesheet",t.href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap",document.head.appendChild(t),chrome.storage.sync.get(o,l=>{const c={...o,...l};(!c.systemPrompt||c.systemPrompt.trim()==="")&&(c.systemPrompt=b),x(c),h(c.theme)})},[]);const h=t=>{t==="dark"||t==="auto"&&window.matchMedia("(prefers-color-scheme: dark)").matches?(document.body.style.background="linear-gradient(135deg, #0f172a 0%, #1e293b 100%)",document.body.style.color="#cbd5e1"):(document.body.style.background="linear-gradient(135deg, #f1f5f9 0%, #cbd5e1 100%)",document.body.style.color="#1e293b")},n=(t,l)=>{const c={...i,[t]:l};x(c),t==="theme"&&h(l)},v=()=>{if(!i.apiKey||i.apiKey.trim()===""){p({text:"⚠️ Önce API anahtarı alanını doldurun!",type:"error"});return}f(!0),p({text:"🔄 Gemini API ile güvenli bağlantı kuruluyor...",type:"info"});const t={action:"TEST_API_CONNECTION",apiKey:i.apiKey,apiModel:i.apiModel};chrome.runtime.sendMessage(t,l=>{if(f(!1),chrome.runtime.lastError){p({text:`❌ Bağlantı hatası: ${chrome.runtime.lastError.message}`,type:"error"});return}l.success?p({text:`✅ Bağlantı Başarılı! Gemini yanıt verdi: "${l.data}"`,type:"success"}):p({text:`❌ Test Başarısız! Hata: ${l.error}`,type:"error"})})},j=t=>{if(t.preventDefault(),!i.apiKey||i.apiKey.trim()===""){d({text:"⚠️ Lütfen Google Gemini API anahtarınızı girin!",type:"error"});return}chrome.storage.sync.set(i,()=>{chrome.runtime.lastError?d({text:`❌ Kayıt hatası: ${chrome.runtime.lastError.message}`,type:"error"}):(d({text:"✅ Ayarlar başarıyla kaydedildi!",type:"success"}),setTimeout(()=>{d({text:"",type:""})},2500))})},S=t=>{t.preventDefault(),x(o),h(o.theme),d({text:"↻ Ayarlar varsayılana sıfırlandı (henüz kaydedilmedi)",type:"success"}),setTimeout(()=>{d({text:"",type:""})},2500)},N=()=>{n("systemPrompt",b),d({text:"✅ Varsayılan System Prompt yüklendi (kaydetmeyi unutmayın)",type:"success"}),setTimeout(()=>{d({text:"",type:""})},2500)},a=i.theme==="dark"||i.theme==="auto"&&window.matchMedia("(prefers-color-scheme: dark)").matches;return e.jsxs("div",{className:"container",style:a?r.container:s.container,children:[e.jsx("style",{children:`
        body {
          font-family: 'Outfit', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          min-height: 100vh;
          padding: 40px 20px;
          transition: background 0.3s, color 0.3s;
        }
        .container {
          max-width: 650px;
          margin: 0 auto;
          border-radius: 16px;
          box-shadow: 0 20px 50px rgba(0,0,0,0.3);
          padding: 40px;
          transition: background 0.3s, color 0.3s, border-color 0.3s;
        }
        h1 {
          margin-bottom: 30px;
          text-align: center;
          border-bottom: 1px solid rgba(255,255,255,0.08);
          padding-bottom: 20px;
          font-size: 26px;
          font-weight: 700;
        }
        h1 span {
          color: #10b981;
        }
        .settings-group {
          margin-bottom: 30px;
          padding: 25px;
          border-radius: 12px;
          border-left: 4px solid #10b981;
          transition: background 0.3s, border-color 0.3s;
        }
        .settings-group h2 {
          font-size: 16px;
          font-weight: 600;
          margin-bottom: 20px;
          display: flex;
          align-items: center;
          gap: 10px;
          margin-top: 0;
        }
        .setting-item {
          margin-bottom: 20px;
          padding-bottom: 20px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .setting-item:last-child {
          margin-bottom: 0; padding-bottom: 0; border-bottom: none;
        }
        .setting-item label {
          display: block; font-weight: 500;
          margin-bottom: 8px; font-size: 13px;
        }
        .setting-item .description {
          font-size: 12px; color: #64748b; margin-top: 6px; line-height: 1.5;
        }
        .setting-item .description a {
          color: #3b82f6;
          text-decoration: none;
        }
        .setting-item .description a:hover {
          text-decoration: underline;
        }
        input[type="text"],
        input[type="password"],
        input[type="number"],
        select,
        textarea {
          width: 100%; padding: 10px 12px; 
          border-radius: 8px; font-family: inherit;
          font-size: 13px; transition: all 0.3s;
        }
        input[type="checkbox"] {
          margin-right: 10px; cursor: pointer; width: 16px; height: 16px;
          accent-color: #10b981;
        }
        .checkbox-label { display: flex; align-items: center; font-size: 13px; cursor: pointer; }
        .button-group {
          display: flex; gap: 15px; margin-top: 30px; justify-content: center;
        }
        button {
          padding: 12px 30px; border: none; border-radius: 8px;
          cursor: pointer; font-weight: 600; font-size: 13px;
          transition: all 0.3s ease; text-transform: uppercase; letter-spacing: 0.5px;
          font-family: inherit;
        }
        .divider {
          height: 1px;
          margin: 30px 0;
        }
        .model-hint {
          font-size: 11px; color: #64748b; margin-top: 6px;
        }
      `}),e.jsxs("h1",{children:["🔧 Eklenti ",e.jsx("span",{children:"Ayarları"})]}),(!i.apiKey||i.apiKey.trim()==="")&&e.jsxs("div",{style:a?r.apiKeyWarning:s.apiKeyWarning,children:["⚠️ ",e.jsx("strong",{children:"API Anahtarı Bulunamadı!"})," Eklentiyi kullanmak için aşağıya Google Gemini API anahtarınızı girin ve ",e.jsx("strong",{children:"Kaydet"}),"'e basın."]}),e.jsx("div",{style:a?r.infoBanner:s.infoBanner,children:"💡 Tüm ayarları buradan özelleştirebilirsiniz. Gemini API anahtarı ve model adı burada saklanır ve güvenli bir şekilde arka plan servisinde (Service Worker) çalıştırılır."}),e.jsxs("form",{onSubmit:j,children:[e.jsxs("div",{className:"settings-group",style:a?r.settingsGroup:s.settingsGroup,children:[e.jsx("h2",{children:"🔑 API Ayarları"}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"Google Gemini API Anahtarı"}),e.jsxs("div",{style:{display:"flex",gap:"10px"},children:[e.jsx("input",{type:"password",value:i.apiKey,onChange:t=>n("apiKey",t.target.value),placeholder:"AIza... şeklinde API anahtarınızı girin",style:a?r.input:s.input}),e.jsx("button",{type:"button",onClick:v,disabled:y,style:{background:"linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)",color:"white",padding:"10px 15px",borderRadius:"8px",fontSize:"12px",minWidth:"140px",margin:0,textTransform:"none",letterSpacing:0,fontWeight:600,boxShadow:"0 4px 10px rgba(59,130,246,0.15)"},children:y?"⏳ Test Ediliyor...":"⚡ Bağlantıyı Test Et"})]}),g.text&&e.jsx("div",{style:{fontSize:"12px",marginTop:"8px",fontWeight:500,padding:"6px 10px",borderRadius:"4px",...k(g.type)},children:g.text}),e.jsxs("div",{className:"description",children:[e.jsx("a",{href:"https://aistudio.google.com/app/apikey",target:"_blank",rel:"noreferrer",children:"Google AI Studio"}),"'dan ücretsiz alabilirsiniz."]})]}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"AI Model Adı"}),e.jsx("input",{type:"text",value:i.apiModel,onChange:t=>n("apiModel",t.target.value),placeholder:"gemini-2.5-flash",style:a?r.input:s.input}),e.jsxs("div",{className:"model-hint",children:["Örnek modeller: ",e.jsx("code",{children:"gemini-2.5-flash"})," · ",e.jsx("code",{children:"gemini-2.5-pro"})," · ",e.jsx("code",{children:"gemini-2.0-flash"})," · ",e.jsx("code",{children:"gemini-1.5-pro"})]}),e.jsx("div",{className:"description",children:"Kullanmak istediğiniz Gemini model adını yazın."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"API Zaman Aşımı (saniye)"}),e.jsx("input",{type:"number",value:i.apiTimeout,min:"5",max:"300",onChange:t=>n("apiTimeout",parseInt(t.target.value)||o.apiTimeout),style:a?r.input:s.input}),e.jsx("div",{className:"description",children:"API isteğinin maksimum bekleme süresi."})]})]}),e.jsx("div",{className:"divider",style:a?r.divider:s.divider}),e.jsxs("div",{className:"settings-group",style:a?r.settingsGroup:s.settingsGroup,children:[e.jsx("h2",{children:"🕷️ Web Kazıcı Ayarları"}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"Maksimum Eleman Sayısı"}),e.jsx("input",{type:"number",value:i.maxElements,min:"1",max:"1000",onChange:t=>n("maxElements",parseInt(t.target.value)||o.maxElements),style:a?r.input:s.input}),e.jsx("div",{className:"description",children:"Tek seferde işlenecek maksimum sayfa elemanı."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"İstekler Arası Gecikme (ms)"}),e.jsx("input",{type:"number",value:i.delayMs,min:"0",max:"5000",onChange:t=>n("delayMs",parseInt(t.target.value)||o.delayMs),style:a?r.input:s.input}),e.jsx("div",{className:"description",children:"Ardışık istekler arasında bekleme süresi."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsxs("label",{className:"checkbox-label",children:[e.jsx("input",{type:"checkbox",checked:i.autoScroll,onChange:t=>n("autoScroll",t.target.checked)}),e.jsx("span",{children:"Otomatik Kaydırma"})]}),e.jsx("div",{className:"description",children:"Veri toplama sırasında sayfayı otomatik kaydır."})]})]}),e.jsx("div",{className:"divider",style:a?r.divider:s.divider}),e.jsxs("div",{className:"settings-group",style:a?r.settingsGroup:s.settingsGroup,children:[e.jsx("h2",{children:"🎨 Görünüm ve Davranış"}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"Tema"}),e.jsxs("select",{value:i.theme,onChange:t=>n("theme",t.target.value),style:a?r.select:s.select,children:[e.jsx("option",{value:"light",children:"Açık Tema"}),e.jsx("option",{value:"dark",children:"Koyu Tema"}),e.jsx("option",{value:"auto",children:"Sistem Teması"})]}),e.jsx("div",{className:"description",children:"Eklentinin görünüm teması."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsxs("label",{className:"checkbox-label",children:[e.jsx("input",{type:"checkbox",checked:i.notifications,onChange:t=>n("notifications",t.target.checked)}),e.jsx("span",{children:"Bildirimleri Göster"})]}),e.jsx("div",{className:"description",children:"İşlem sonuçları hakkında bildirim göster."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"Günlük Seviyesi"}),e.jsxs("select",{value:i.logLevel,onChange:t=>n("logLevel",t.target.value),style:a?r.select:s.select,children:[e.jsx("option",{value:"info",children:"Bilgi"}),e.jsx("option",{value:"debug",children:"Hata Ayıklama"}),e.jsx("option",{value:"error",children:"Sadece Hatalar"})]}),e.jsx("div",{className:"description",children:"Kaydedilecek günlük detay seviyesi."})]})]}),e.jsx("div",{className:"divider",style:a?r.divider:s.divider}),e.jsxs("div",{className:"settings-group",style:a?r.settingsGroup:s.settingsGroup,children:[e.jsx("h2",{children:"⚙️ Gelişmiş Ayarlar"}),e.jsxs("div",{className:"setting-item",children:[e.jsxs("label",{className:"checkbox-label",children:[e.jsx("input",{type:"checkbox",checked:i.enableDebug,onChange:t=>n("enableDebug",t.target.checked)}),e.jsx("span",{children:"Hata Ayıklama Modu"})]}),e.jsx("div",{className:"description",children:"Tarayıcı konsolunda ayrıntılı günlükler göster."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsxs("label",{className:"checkbox-label",children:[e.jsx("input",{type:"checkbox",checked:i.cacheData,onChange:t=>n("cacheData",t.target.checked)}),e.jsx("span",{children:"Verileri Önbelleğe Al"})]}),e.jsx("div",{className:"description",children:"Başarılı istekleri yerel belleğe kaydet."})]}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"Yeniden Deneme Sayısı"}),e.jsx("input",{type:"number",value:i.retryAttempts,min:"0",max:"10",onChange:t=>n("retryAttempts",parseInt(t.target.value)||o.retryAttempts),style:a?r.input:s.input}),e.jsx("div",{className:"description",children:"Başarısız istekleri yeniden deneme sayısı."})]})]}),e.jsx("div",{className:"divider",style:a?r.divider:s.divider}),e.jsxs("div",{className:"settings-group",style:a?r.settingsGroup:s.settingsGroup,children:[e.jsx("h2",{children:"🧠 System Prompt Özelleştirmesi"}),e.jsxs("div",{className:"setting-item",children:[e.jsx("label",{children:"AI Komut Sistemi (System Prompt)"}),e.jsx("textarea",{value:i.systemPrompt,onChange:t=>n("systemPrompt",t.target.value),style:{width:"100%",height:"180px",padding:"10px",fontFamily:"'Courier New', monospace",fontSize:"12px",resize:"vertical",lineHeight:1.5,...a?r.textarea:s.textarea}}),e.jsx("div",{className:"description",children:"Yapay zekaya verilen talimatlar. Boş bırakırsanız veya sıfırlarsanız varsayılan prompt kullanılır."}),e.jsx("button",{type:"button",onClick:N,style:{width:"100%",padding:"10px",marginTop:"12px",background:"linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",color:"white",border:"none",borderRadius:"8px",cursor:"pointer",fontWeight:600,fontSize:"12px",textTransform:"none",letterSpacing:0,boxShadow:"0 4px 10px rgba(245,158,11,0.15)"},children:"⟲ VARSAYILAN SYSTEM PROMPT'U GERİ YÜKLE"})]})]}),e.jsxs("div",{className:"button-group",children:[e.jsx("button",{type:"submit",style:{background:"linear-gradient(135deg, #10b981 0%, #059669 100%)",color:"white",minWidth:"140px",boxShadow:"0 4px 14px rgba(16, 185, 129, 0.2)"},children:"💾 Kaydet"}),e.jsx("button",{type:"button",onClick:S,style:{background:a?"rgba(255,255,255,0.06)":"#e2e8f0",color:a?"#cbd5e1":"#1e293b",border:a?"1px solid rgba(255,255,255,0.08)":"1px solid #cbd5e1",minWidth:"140px"},children:"↻ Sıfırla"})]}),u.text&&e.jsx("div",{style:{marginTop:"20px",padding:"12px",borderRadius:"8px",textAlign:"center",fontWeight:600,fontSize:"13px",animation:"slideIn 0.3s ease",...k(u.type)},children:u.text})]})]})},k=i=>i==="success"?{background:"rgba(16, 185, 129, 0.1)",color:"#34d399",border:"1px solid rgba(16, 185, 129, 0.2)"}:i==="error"?{background:"rgba(239, 68, 68, 0.1)",color:"#f87171",border:"1px solid rgba(239, 68, 68, 0.2)"}:{background:"rgba(56, 189, 248, 0.1)",color:"#38bdf8",border:"1px solid rgba(56, 189, 248, 0.2)"},r={container:{background:"rgba(30, 41, 59, 0.7)",border:"1px solid rgba(255, 255, 255, 0.08)"},settingsGroup:{background:"rgba(255, 255, 255, 0.02)",borderColor:"rgba(255, 255, 255, 0.04)"},input:{background:"rgba(15, 23, 42, 0.6)",border:"1px solid rgba(255, 255, 255, 0.1)",color:"#ffffff"},select:{background:"rgba(15, 23, 42, 0.6)",border:"1px solid rgba(255, 255, 255, 0.1)",color:"#ffffff"},textarea:{background:"rgba(15, 23, 42, 0.6)",border:"1px solid rgba(255, 255, 255, 0.1)",color:"#ffffff"},divider:{background:"rgba(255, 255, 255, 0.06)"},apiKeyWarning:{background:"rgba(245, 158, 11, 0.1)",borderLeft:"4px solid #f59e0b",padding:"12px 16px",marginBottom:"25px",borderRadius:"8px",fontSize:"13px",color:"#fbbf24",lineHeight:1.5},infoBanner:{background:"rgba(59, 130, 246, 0.08)",borderLeft:"4px solid #3b82f6",padding:"15px",marginBottom:"25px",borderRadius:"8px",fontSize:"13px",color:"#93c5fd",lineHeight:1.5}},s={container:{background:"#ffffff",border:"1px solid #cbd5e1"},settingsGroup:{background:"#f8fafc",borderColor:"#cbd5e1"},input:{background:"#ffffff",border:"1px solid #cbd5e1",color:"#1e293b"},select:{background:"#ffffff",border:"1px solid #cbd5e1",color:"#1e293b"},textarea:{background:"#ffffff",border:"1px solid #cbd5e1",color:"#1e293b"},divider:{background:"#cbd5e1"},apiKeyWarning:{background:"#fef3c7",borderLeft:"4px solid #d97706",padding:"12px 16px",marginBottom:"25px",borderRadius:"8px",fontSize:"13px",color:"#92400e",lineHeight:1.5},infoBanner:{background:"#dbeafe",borderLeft:"4px solid #2563eb",padding:"15px",marginBottom:"25px",borderRadius:"8px",fontSize:"13px",color:"#1e40af",lineHeight:1.5}};A.createRoot(document.getElementById("root")).render(e.jsx(T.StrictMode,{children:e.jsx(z,{})}));
