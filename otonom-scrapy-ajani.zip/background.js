(function(){"use strict";const m={apiKey:"",apiModel:"gemini-2.5-flash",apiTimeout:30,maxElements:500,delayMs:1e3,autoScroll:!0,theme:"dark",notifications:!0,logLevel:"info",enableDebug:!1,cacheData:!0,retryAttempts:3,systemPrompt:`Sen kıdemli bir Python ve Scrapy geliştiricisisi ve Reverse Engineering uzmanısın.
Kullanıcı senin için hedef sitelerde adım adım dolaştı ve verileri topladı.

JSON formatında yapılandırılmış veri alacaksın. Her adımda:
1. HTML öğeleri ve onun bulunduğu sayfa
2. API istekleri ve yanıtları

KURALLAR:
1. API (XHR/Fetch) verisi varsa DAİMA onu kullanmayı (JSON Parse) önceliklendir.
2. Sınıf ismi \`{SPIDER_NAME}Spider\` olsun.
3. Çıktıyı \`yield\` kullanarak verilen format'taki dictionary döndür.
4. Çekilen verilerdeki boşlukları \`.strip()\` ile temizle.
5. Hata almamak için try-except kullan.
6. SADECE ÇALIŞTIRILABİLİR PYTHON KODUNU VER. Markdown backticks dışında açıklama yazma.`};chrome.runtime.onInstalled.addListener(()=>{chrome.storage.sync.get(Object.keys(m),e=>{const a={...m,...e};chrome.storage.sync.set(a)})}),chrome.runtime.onMessage.addListener((e,a,r)=>{var o;if(e.action==="GET_TAB_ID")return r({tabId:(o=a.tab)==null?void 0:o.id}),!1;if(e.action==="GEMINI_CALL")return f(e.payload).then(t=>r({success:!0,data:t})).catch(t=>r({success:!1,error:t.message})),!0;if(e.action==="TEST_API_CONNECTION")return T(e.apiKey,e.apiModel).then(t=>r({success:!0,data:t})).catch(t=>r({success:!1,error:t.message})),!0});async function f(e){const{apiKey:a,apiModel:r,systemPrompt:o,content:t}=e,s=`https://generativelanguage.googleapis.com/v1beta/models/${r}:generateContent?key=${a}`,y={system_instruction:{parts:[{text:o}]},contents:[{parts:[{text:typeof t=="string"?t:JSON.stringify(t,null,2)}]}]},i=await fetch(s,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(y)});if(!i.ok){const c=await i.text();let l=`HTTP Hata Kodu: ${i.status}`;try{const n=JSON.parse(c);n.error&&n.error.message&&(l=n.error.message)}catch{}throw new Error(l)}return await i.json()}async function T(e,a){var u,c,l,n,p,g;const o=`https://generativelanguage.googleapis.com/v1beta/models/${a||"gemini-2.5-flash"}:generateContent?key=${e}`,s=await fetch(o,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:"Hello! Reply with exactly one word: OK"}]}]})});if(!s.ok){const k=await s.text();let h=`HTTP Hata Kodu: ${s.status}`;try{const d=JSON.parse(k);d.error&&d.error.message&&(h=d.error.message)}catch{}throw new Error(h)}return((g=(p=(n=(l=(c=(u=(await s.json()).candidates)==null?void 0:u[0])==null?void 0:c.content)==null?void 0:l.parts)==null?void 0:n[0])==null?void 0:p.text)==null?void 0:g.trim())||""}})();
